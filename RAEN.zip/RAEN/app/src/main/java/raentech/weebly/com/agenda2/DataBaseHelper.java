package raentech.weebly.com.agenda2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper{

    private static final String TAG = "DataBaseHelper";

    private static final String TABLE_NAME = "event_table";
    private static final String COL1 = "ID";
    private static final String COL2 = "events";

    public DataBaseHelper(Context context){

        super(context, TABLE_NAME, null, 1);

        @Override
        public void onCreate(SQLiteDatabase db){
            String createT = "Create Table" + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT," + COL2 + "TEXT)";
            db.execSQL(createT);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
            db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
            onCreate(db);
        }

    }


}
